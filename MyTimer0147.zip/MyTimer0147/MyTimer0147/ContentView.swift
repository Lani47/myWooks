//
//  ContentView.swift
//  MyTimer0147
//
//  Created by cmStudent on 2021/06/04.
//

import SwiftUI

struct ContentView: View {
    //大麻の変数 まだ未確定
    @State var timerhandler : Timer?
    //経過時間のカウント
    @State var count = 0
    //永続化する秒数設定 なんと勝手に保存してくれる
    @AppStorage("timer_value") var timerValue = 10
    //アラーム表示
    @State var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack {
                
                Image("backgroundTimer")
                    .resizable()
                    .edgesIgnoringSafeArea(.all)
                    .aspectRatio(contentMode: .fill)
                
                VStack(spacing: 30.0){
                    Text("残り\(timerValue - count)秒")
                        .font(.largeTitle)
                    
                    HStack {
                        Button {
                            //タイマーを起動する
                            startTimer()
                            
                        } label: {
                            //見た目
                            Text("スタート")
                                .font(.title)
                                .foregroundColor(Color.white)
                                .frame(width: 140, height: 140)
                                .background(Color("startColor"))
                                //  円形にする
                                .clipShape(Circle())
                            //                                .background(Color("startColor"))
                            //
                        }
                        Button {
                            //
                            if let unwrapdTimerHandler = timerhandler {
                                if unwrapdTimerHandler.isValid == true {
                                    //タイマー停止
                                    unwrapdTimerHandler.invalidate()
                                }
                            }
                            
                        } label: {
                            //見た目
                            Text("ストップ")
                                .font(.title)
                                .foregroundColor(Color.white)
                                .frame(width: 140, height: 140)
                                .background(Color("stopColor"))
                                //  円形にする
                                .clipShape(Circle())
                            
                            //                                .mask(
                            //                                Text("hoge"))
                            //                                .font(.largeTitle)
                        }
                    }
                }//VStack
            }//ZStack
            //画面が表示されたら実
            
            .onAppear {
                //カウントをリセット
                count = 0
            }
            
            //ナビゲーションバーにボタンを追加
            .navigationBarItems(trailing:
                                    //ナビゲーション推移
                                    NavigationLink(
                                        destination: SettingView()) {
                                        //テキスト表示
                                        Text("秒数設定")
                                    }
                                
                                
            )
            
        }//ナビ
        //アラートを出す
        .alert(isPresented: $showAlert) {
            
            //説明のタイトル
            Alert(title: Text("終了"),
                  //説明の内容
                  message: Text("タイマー終了時間です。") ,
                  //押す方
                  dismissButton: .default(Text("ok")))
        }
    }
    //大麻のカウントダウん
    func countDownTimer(){
        //経過時間の処理
        count += 1
        
        //時間が来たらタイマーを止める
        if timerValue - count <= 0 {
            //ここで停止する
            timerhandler?.invalidate()
            //アラートを表示する
            showAlert = true
        }
    }
    //大麻を開始する関数
    func startTimer() {
        //timerHandlreをアンラップして代入
        if let unwrapedTimeHander = timerhandler {
            //大麻が実行中ならスタートしない
            if unwrapedTimeHander.isValid == true {
                //実行させないためにリターンする
                return
            }
        }
        if timerValue - count <= 0 {
            count = 0
        }
        //タイマーを起動する
        timerhandler = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            //１秒毎に呼び出す
            countDownTimer()
            
        }
    }//startTimerここまで
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
