//
//  MyTimer0147App.swift
//  MyTimer0147
//
//  Created by cmStudent on 2021/06/04.
//

import SwiftUI

@main
struct MyTimer0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
