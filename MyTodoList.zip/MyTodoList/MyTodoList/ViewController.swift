//
//  ViewController.swift
//  MyTodoList
//
//  Created by cmStudent on 2020/07/24.
//  Copyright © 2020 20CM0103. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    //todoを格納した配列
    var todoList = [MyTodo]()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //todoを読み込む
        let userDefaults = UserDefaults.standard
        if let storedTodoList = userDefaults.object(forKey: "todoList") as? Data {
            do {
                if let unarchiveTodoList = try NSKeyedUnarchiver.unarchivedObject(ofClasses: [NSArray.self, MyTodo.self],from: storedTodoList) as?
                    [MyTodo] {
                    todoList.append(contentsOf: unarchiveTodoList)
                }
            } catch {
                //エラ〜処理なし
            }
        }
        
    }
    // +ボタンをタップしたときに呼ばれる処理
    @IBAction func tapAddButton(_ sender: Any) {
        //アラートダイアログを作成
        let alertController = UIAlertController(title: "ToDo追加", message: "ToDoを入力してください", preferredStyle:  UIAlertController.Style.alert)
        
        //テキストエリアを追加
        alertController.addTextField(configurationHandler: nil)
        //OKボタンを追加
        let okAction = UIAlertAction(title: "OK!", style: UIAlertAction.Style.default) { (action:UIAlertAction) in
            //OKボタンが押された時の処理
            if let textField = alertController.textFields?.first{
                //ToDoの配列に入力値を押収。先端に押収するc
                let myTodo = MyTodo()
                myTodo.todoTitle = textField.text!
                self.todoList.insert(myTodo, at: 0)
                //テーブルに行が追加されたことをテーブルに知いつ
                self.tableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: UITableView.RowAnimation.right)
                //ToDoの保存処理
                let userDefaults = UserDefaults.standard
                //Data型にシリアライズする
                do {
                    let data = try NSKeyedArchiver.archivedData(withRootObject: self.todoList, requiringSecureCoding: true)
                userDefaults.set(data, forKey: "todoList")
                userDefaults.synchronize()
                } catch {
                    //エラー処理なし
                }
            }
        }
        //OKボタンが押された時の処理
        alertController.addAction(okAction)
        //CANSELボタンがタップさらた時の処理
        let canselButton = UIAlertAction(title: "CANSEL", style: UIAlertAction.Style.cancel, handler: nil)
        //CANSELボタンを追加
        alertController.addAction(canselButton)
        //アラートダイアログ
        present(alertController, animated: true, completion: nil)
        
    }
    //tableの行数を返却する
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //todoの配列の長さを返却する
        return todoList.count
    }
    
    //tableの行ごとのCellを返却する
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Storeboaydで指定したtodoCcll識別子を利用して再利用が可能なセルを取得する
        let cell = tableView.dequeueReusableCell(withIdentifier: "todoCell", for: indexPath)
        //行番号にあったToDoの情報を取得
        let myTodo = todoList[indexPath.row]
        //セルのラベルにToDoのタイトルをセット
        cell.textLabel?.text = myTodo.todoTitle
        //セルのチェックマーク状態をセット
        if myTodo.todoDone {
            cell.accessoryType = UITableViewCell.AccessoryType.checkmark
        } else {
            //チェックなし
            cell.accessoryType = UITableViewCell.AccessoryType.none
        }
        return cell
    }
    //セルをタップした時の処理
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let myTodo = todoList[indexPath.row]
        if myTodo.todoDone {
            //完了済みなら未完了に変更
            myTodo.todoDone = false
        } else {
            //未完了なら完了に
            myTodo.todoDone = true
        }
        //セルの状態を変更
        tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.fade)
        //Data型にシリアライズする
        do {
            let data = try NSKeyedArchiver.archivedData(withRootObject: todoList, requiringSecureCoding: true)
            //UserDefaultsに保存
            let userDefaults = UserDefaults.standard
            userDefaults.set(data, forKey: "todoList")
            userDefaults.synchronize()
            
            
        } catch {
            //エラー処理なし
        }
        
    }
    //セルが編集可能かどうかを返却する
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //セルを削除した時の処理
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        //削除処理か同化
        if editingStyle == UITableViewCell.EditingStyle.delete {
            //ToDoリストから削除
            todoList.remove(at: indexPath.row)
            //セルを削除
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.fade)
            //データほぞん。DaTa型にシリアライズする
            do {
                let data: Data = try NSKeyedArchiver.archivedData(withRootObject: todoList, requiringSecureCoding: true)
                //UserDefaultsに保存
                let userDefaults = UserDefaults.standard
                userDefaults.set(data, forKey: "todoList")
                userDefaults.synchronize()
            } catch {
                //エラー処理なし
            }
            
        }
    
    }

    
}
class MyTodo: NSObject,  NSSecureCoding{
    static var supportsSecureCoding: Bool{
        return true
    }
    //ToDoのタイトル
    var todoTitle : String?
    //ToDoを完了したかどうかを表すフラグ
    var todoDone: Bool = false
    //コンストラクタ
    override init() {
        
    }
    //NSCodingプロトコルに宣言されているデシリアライズ処理。でこーど処理と呼ばれる
    required init?(coder aDecoder: NSCoder) {
        todoTitle = aDecoder.decodeObject(forKey: "todoTitle") as? String
        todoDone = aDecoder.decodeBool(forKey: "todoDone")
    }
    //NSCodingプロトコルに宣言されているシリアライズ処理。エンコード処理
    func encode(with aCoder: NSCoder) {
        aCoder.encode(todoTitle, forKey: "todoTitle")
        aCoder.encode(todoDone, forKey: "todoDone")
    
    }
    
}

