//
//  MyGoldenWeek0147App.swift
//  MyGoldenWeek0147
//
//  Created by cmStudent on 2021/05/06.
//

import SwiftUI

@main
struct MyGoldenWeek0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
