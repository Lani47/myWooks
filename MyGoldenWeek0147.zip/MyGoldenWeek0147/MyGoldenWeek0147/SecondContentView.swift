//
//  SecondContentView.swift
//  MyGoldenWeek0147
//
//  Created by cmStudent on 2021/05/06.
//

import SwiftUI
import AVKit

struct SecondContentView: View {
    //URL開かせるためのパーツ？
    @Environment(\.openURL) var openURL
    //画像を変数にすることで画像を変えたりできる
    @State private var isFavorite = false
    
    @State var Imagezo = "dog"
    var body: some View {
        VStack{
            Text("画像をタップすると？\n動画が再生します。\n＊wifiでの通信を推奨します。")
            
            
            
            Image("E0voVnuVgAAz2PM").resizable()
                .scaledToFit()      // 縦横比を維持しながらフレームに収める
                .frame(width: 300, height: 150)
                .border(Color.red, width: 2)
                .onTapGesture {
                    openURL(URL(string: "https://www.youtube.com/watch?v=ShRBqegXddo&t=2s")!)
                }
            //ここでどこに移動するか決める
            NavigationLink(
                destination: ThirdContentView()){
                Text("次へ")
            }
            .navigationTitle("夏休みにやったこと")
            
        }
        
    }
}

struct SecondContentView_Previews: PreviewProvider {
    static var previews: some View {
        SecondContentView()
    }
}

