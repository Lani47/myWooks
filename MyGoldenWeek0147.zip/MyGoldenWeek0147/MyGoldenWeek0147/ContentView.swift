//
//  ContentView.swift
//  MyGoldenWeek0147
//
//  Created by cmStudent on 2021/05/06.
//

import SwiftUI

struct ContentView: View {
    
    //画像を変数にすることで画像を変えたりできる
    @State var Imagezo = "dog"
    var body: some View {
        
        NavigationView{
            VStack{
                Image("toy_omocha_asobu_boy").resizable()
                    .scaledToFit()      // 縦横比を維持しながらフレームに収める
                    .frame(width: 300, height: 150)
                    .border(Color.red, width: 2)
                Text("ゴールデンウィークの思い出")
                    .padding()
                Image("game_keitai_broken_kids").resizable()
                    .scaledToFit()      // 縦横比を維持しながらフレームに収める
                    .frame(width: 300, height: 150)
                    .border(Color.red, width: 2)
                
                
                
                //ここでどこに移動するか決める
                NavigationLink(
                    destination: SecondContentView()){
                    Text("次")
                    
                    
                }
                .navigationTitle("はじまり")
            }.navigationViewStyle(StackNavigationViewStyle())
            
            
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
