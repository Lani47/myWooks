//
//  ThirdContentView.swift
//  MyGoldenWeek0147
//
//  Created by cmStudent on 2021/05/07.
//

import SwiftUI

struct ThirdContentView: View {
    //URL開かせるためのパーツ？
    @Environment(\.openURL) var openURL
    var body: some View {
        VStack{
            Text("ゲームしてましたはい。\nこれはウイニングポストという馬主シュミレーションゲームです。")
            Image("E0voK4IVkAIeLTf").resizable()
                .scaledToFit()      // 縦横比を維持しながらフレームに収める
                .frame(width: 300, height: 150)
                .border(Color.red, width: 2)
            //ここでどこに移動するか決める
            NavigationLink(
                destination: ForceContentView()){
                Text("次へ")
            }
            .navigationTitle("後悔...")
            
        }
    }
}

struct ThirdContentView_Previews: PreviewProvider {
    static var previews: some View {
        ThirdContentView()
    }
}
