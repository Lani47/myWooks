//
//  ForceContentView.swift
//  MyGoldenWeek0147
//
//  Created by cmStudent on 2021/05/07.
//

import SwiftUI

struct ForceContentView: View {
    var body: some View {
        VStack{
            Text("ほんとは休み中にこれやりたかった。。。\n深く後悔しています。")
            Image("bookfan_bk-4295007625").resizable()
                .transition(.opacity)
                .padding()
        }
        
    }
}

struct ForceContentView_Previews: PreviewProvider {
    static var previews: some View {
        ForceContentView()
    }
}
