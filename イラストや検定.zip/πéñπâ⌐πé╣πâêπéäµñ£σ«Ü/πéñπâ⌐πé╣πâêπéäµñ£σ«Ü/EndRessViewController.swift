//
//  EndRessViewController.swift
//  イラストや検定
//
//  Created by cmStudent on 2020/09/08.
//  Copyright © 2020 20CM0103. All rights reserved.
//

import UIKit

class EndRessViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
