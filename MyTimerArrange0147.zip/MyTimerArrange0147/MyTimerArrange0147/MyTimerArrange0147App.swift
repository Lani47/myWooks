//
//  MyTimerArrange0147App.swift
//  MyTimerArrange0147
//
//  Created by cmStudent on 2021/06/11.
//

import SwiftUI

@main
struct MyTimerArrange0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
