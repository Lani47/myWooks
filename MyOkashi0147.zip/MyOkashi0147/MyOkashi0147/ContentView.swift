//
//  ContentView.swift
//  MyOkashi0147
//
//  Created by cmStudent on 2021/07/08.
//

import SwiftUI


struct ContentView: View {
    //ただのSwiftファイルの中とデータを参照できる？
    @ObservedObject var okashiDataList = OkashiData()
    @State var inputText = ""
    //別の画面を出したい時はその画面が出ているか？を管理しなければならない？
    @State var showSafari = false
    var body: some View {
        VStack{
            TextField("キーワードを入力してください", text: $inputText, onCommit: {
                okashiDataList.searchOkashi(keyword: inputText)
            })
            
            List(okashiDataList.okashiList) {
                //ここで取り込んだお菓子のデータを全て取り出す？
                okashi in
                Button(action: {
                    showSafari.toggle()
                }){
                    HStack {
                        Image(uiImage: okashi.image)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 40)
                        
                        Text(okashi.name)
                    }
                }
                .sheet(isPresented: self.$showSafari, content: {
                    //ここで作ったviewを表示する
                    SafariView(url: okashi.link)
                    //下をいっぱいにして指定
                        .edgesIgnoringSafeArea(.bottom)
                })
            }//Listここまで
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
