//
//  MyOkashi0147App.swift
//  MyOkashi0147
//
//  Created by cmStudent on 2021/07/08.
//

import SwiftUI

@main
struct MyOkashi0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
