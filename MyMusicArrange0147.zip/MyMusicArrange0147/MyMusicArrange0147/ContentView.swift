//
//  ContentView.swift
//  MyMusicArrange0147
//
//  Created by cmStudent on 2021/05/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var guitarvalue: Double = 0
    //音を使い分ける設定
    @State var musicValue = 0
    @State var count = 0
    
    
    //音を鳴らすためのクラスをインスタンス
    let soundPalyer = SoundPlayer()
    var body: some View {
        ZStack{
            Image("background").resizable()
                .edgesIgnoringSafeArea(.all)
            //これがあると無理やりZStackを広げてしまう？
            //融通が効かないのかな
            //.aspectRatio(contentMode: .fill)
            VStack{
                Picker(selection: $musicValue, label:
                        Text("musicPiker"), content: {
                            Text("シンバル").tag(1)
                            Text("和太鼓").tag(2)
                            Text("呪い").tag(3)
                            Text("改札").tag(4)
                        })
                Slider(value: $guitarvalue, in: 0...5, step: 1)
                    .frame(maxWidth: .infinity)
                if (guitarvalue >= 5){
                    Text("sigo")
                }else if (guitarvalue == 4) {
                    Text("サニーブライアン")
                }else if (guitarvalue == 3) {
                    Text("ディープラスト")
                }else if (guitarvalue == 2) {
                    Text("河内の夢")
                }else if (guitarvalue == 1) {
                    Text("毎日王冠")
                }else if (guitarvalue == 0) {
                    Text("ギター")
                } else {
                    Text("現在の値：\(guitarvalue)")
                }
                
                
                
                
                HStack{
                    
                    Button(action: {
                        if(musicValue == 1){
                            soundPalyer.cymbalPlay()
                            print("シンバル")
                        } else if (musicValue == 2){
                            soundPalyer.wadaikoPlay()
                            print("和太鼓")
                        }else if(musicValue == 3) {
                            soundPalyer.noroiPlay()
                            
                            print("呪い")
                        }else if(musicValue == 4){
                            soundPalyer.kaisatuPlay()
                            print("改札")
                        }
                        
                        
                    }) {
                        Image("cymbal")
                        //                        ButtonImageView(imageName: "cymbal")
                    }
                    Button(action: {
                        if(guitarvalue == 1){
                            soundPalyer.mainichiPlay()
                            print("シンバル")
                        } else if (guitarvalue == 2){
                            soundPalyer.kawachiPlay()
                            print("河内の夢")
                        } else if(guitarvalue == 3) {
                            soundPalyer.dhiipPlay()
                            print("ディープラスト")
                        } else if(guitarvalue == 4){
                            soundPalyer.saniburaunPlay()
                            print("サニーブライアン")
                        } else if(guitarvalue == 5){
                            soundPalyer.sigoPlay()
                            print("sigo")
                        } else {
                            
                              if (count == 0)
                              {soundPalyer.guitarPlay()
                                count += 1
                                print("ギター")
                            } else if (count == 1){
                                soundPalyer.guitarPlay1()
                                print("ギター1")
                                count += 1
                            } else if (count == 2){
                                soundPalyer.guitarPlay2()
                                print("ギター2")
                                count += 1
                            } else if (count == 3){
                                soundPalyer.guitarPlay3()
                                print("ギター3")
                                count = 0
                            }
                            
                            
                        }
                        
                    }) {
                        Image("guitar")
                        //                        ButtonImageView(imageName: "guitar")
                        
                    }
                }
                
            }
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

