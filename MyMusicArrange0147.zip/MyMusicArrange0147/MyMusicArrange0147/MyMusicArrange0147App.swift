//
//  MyMusicArrange0147App.swift
//  MyMusicArrange0147
//
//  Created by cmStudent on 2021/05/21.
//

import SwiftUI

@main
struct MyMusicArrange0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
