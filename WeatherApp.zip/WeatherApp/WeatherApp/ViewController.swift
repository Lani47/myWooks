//
//  ViewController.swift
//  WeatherApp
//
//  Created by cmStudent on 2020/11/30.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mailLavel: UILabel!
    @IBOutlet weak var tenkiLavel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var weatherBackGround: UIImageView!
    //セットする画像セット
    var imgRain = UIImage(named: "雨の背景")
    var imgCloudy = UIImage(named: "imgstyle.info_1213L")
    var imgsunny = UIImage(named: "229_sun-light_sky_cloud_cloud_6650-1024x683")
    var imgThunderstorm = UIImage(named: "雷雨")
    var imgSnow = UIImage(named: "雪国")
    var imgAlsoAnd = UIImage(named: "靄")
    
    
    var ondo = 0.0
    //    let url = "https://api.openweathermap.org/data/2.5/onecall?lat=35.69861666338937&lon=139.69808981103378&units=metric&exclude=&lang=ja&appid=ca7e2964e0d219751f10f8eb558bc0b9"
    //URLを書く
    let url = "https://api.openweathermap.org/data/2.5/onecall"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        //ここら辺でjson利用するためのしょり
        guard var urlComponents = URLComponents(string: url) else {
            print("エラーテスト")
            return
        }
        //URLをいじっても良いように
        urlComponents.queryItems = [
            URLQueryItem(name: "lat", value: "35.69861666338937"),
            URLQueryItem(name: "lon", value: "139.69808981103378"),
            URLQueryItem(name: "lang", value: "ja"),
            URLQueryItem(name: "units", value: "metric"),
            URLQueryItem(name: "appid", value: "ca7e2964e0d219751f10f8eb558bc0b9")
        ]
        //ここで情報をプリント
        let task = URLSession.shared.dataTask(with: urlComponents.url!) {
            data, response, error in
            do {//decodeが関数
                let data = try JSONDecoder().decode(OneCallWeather.self, from: data!)
                print(data)
                DispatchQueue.main.async {
//                    //背景画像セット 天気によって変える
//                    let string : String = (data.current.weather[0].description)
//                   print(string)
//                    if string.lowercased().contains("曇") { // true
//                        print("曇りの画像")
//                        self.weatherBackGround.image = self.imgCloudy
//                    }
//                    else if string.lowercased().contains("雨") {
//                        self.weatherBackGround.image = self.imgRain
//                        print("雨の画像")
//                    }else if string.lowercased().contains("晴"){
//                        self.weatherBackGround.image = self.imgsunny
//                        print("晴のがぞうむ")
//                    }else {
//                        self.weatherBackGround.image = self.imgsunny
//                        print("該当がないのでとりあえず晴れ")
//                    }
                    //雷雨の画像表示
                    //範囲指定はこう使う
                    let weatherId = data.current.weather[0].id
                    if (200...299).contains(weatherId) {//雷雨の背景
                        self.weatherBackGround.image = self.imgThunderstorm
                    } else if (300...399).contains(weatherId) {//霧雨の背景
                        self.weatherBackGround.image = self.imgRain
                    } else if (500...599).contains(weatherId){//雨の背景
                        self.weatherBackGround.image = self.imgRain
                    } else if (600...699).contains(weatherId){//雪の背景
                        self.weatherBackGround.image = self.imgSnow
                    } else if (700...799).contains(weatherId){//靄の背景
                        self.weatherBackGround.image = self.imgAlsoAnd
                    } else if (weatherId == 800){//晴れの背景
                        self.weatherBackGround.image = self.imgsunny
                    } else if (801...804).contains(weatherId){//曇りの背景
                        self.weatherBackGround.image = self.imgCloudy
                    } else{
                    print("該当がないためとりあえず晴れ")
                        self.weatherBackGround.image = self.imgsunny
                    }
                    
                    
                    //天気を入れる
                    self.tenkiLavel.text  = (data.current.weather[0].description)
                    //温度を四捨五入して入れる
                    self.ondo = (data.current.temp)
                    self.ondo = round(self.ondo)
                    self.mailLavel.text = "\(String(self.ondo))度"
                    //画像のURLを取得
                    let urlString = "https://openweathermap.org/img/wn/" + data.current.weather[0].icon
                    + "@2x.png"
                    print("画像のURL:\(urlString)")
                    
                    if let url = URL(string: urlString) {
                        
                        if let imagedata = try? Data(contentsOf: url) {
                            
                            self.weatherIcon.image = UIImage(data: imagedata)

                            
                        } else {
                            print("ロゴ画像データを取得できない")
                        }
                    } else {
                        print("レストンす待ち or 通信エラー")
                    }
                    
                    
                }
                
            } catch {
//                print(error)
            }
        }
        
        task.resume()
        //ここまで大体jsonのテンプレ
        
        
        
        
        
        // Do any additional setup after loading the view.
    }
    func getImageByUrl(url: String) -> UIImage{
        let url = URL(string: url)
        do {
            let data = try Data(contentsOf: url!)
            return UIImage(data: data)!
        } catch let err {
            print("Error : \(err.localizedDescription)")
        }
        return UIImage()
    }
    
//    extension UIImage {
//        public convenience init(url: String) {
//            let url = URL(string: url)
//            do {
//                let data = try Data(contentsOf: url!)
//                self.init(data: data)!
//                return
//            } catch let err {
//                print("Error : \(err.localizedDescription)")
//            }
//            self.init()
//        }
//    }
//
}

