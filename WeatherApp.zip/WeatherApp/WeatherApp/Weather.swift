//
//  Weather.swift
//  WeatherApp
//
//  Created by cmStudent on 2020/11/30.
//

import Foundation

struct OneCallWeather: Decodable{
    let lat : Double
    let lon: Double
    let timezone: String
    let current: Current

    struct Current : Decodable {
        let dt : Int//現在時刻
        let temp : Double//気温
//      let humidity : Double
        let pressure: Int
        //配列で取得する場合もある。
        let weather : [Weather]
        struct Weather : Decodable{//天気
            
            let id : Int
            let main : String
            let description : String
            let icon : String
            

            
        }
    }
        
            
    }
        
    
    
//    let id: String    //番組ID    ◯
//    let event_id:  String    //番組イベントID    ◯
//    let start_time: String    //放送開始日時（YYYY-MM-DDTHH:mm:ssZ形式）    ◯
//    let end_time: String    //放送終了日時（YYYY-MM-DDTHH:mm:ssZ形式）    ◯
//    let area: Area    //Areaオブジェクト    ◯
//    let service : Service    //Serviceオブジェクト    ◯
//    let title : String    //番組名    ◯
//    let subtitle: String    //番組内容    ◯
//    let genres: [String]   //番組ジャンル    ◯
//
//    struct Area: Codable {
//        let id: String
//        let name: String
//
//    }



