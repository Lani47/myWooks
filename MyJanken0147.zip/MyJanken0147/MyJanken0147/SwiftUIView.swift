//
//  SwiftUIView.swift
//  MyJanken0147
//
//  Created by cmStudent on 2021/05/14.
//

import SwiftUI

struct SwiftUIView: View {
    @State var Halo = true
    var body: some View {
        VStack{
            Text(Halo ? "普通モード" : "インチキモード")
            //普通
            Button(action: {
                self.Halo.toggle()
            }) {
                Text("モード切り替え")
            }
            
        }
        
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
