//
//  ContentView.swift
//  MyJanken0147
//
//  Created by cmStudent on 2021/05/13.
//

import SwiftUI



struct ContentView: View {
    //SoundPlayer内のfuncをこのクラスで使えるようにするためのインスタンス生成
    let soundPlayer = SoundPlayer()
    
    @State var ansorNumber = 0
    @State var bakusin = 0
    @State var rojita = 0
    @State var bottonBool = true
    @State var textbox = "これからジャンケンをします。"
//    @Binding var Halo : Bool
    
    @State var flag = false
    
    @State var timerHandler : Timer?
    //画像を変数にすることで画像を変えたりできる
    @State var Imagezo = "cat"
    //秒を数える変数
    @State var count = 0
    
    //画像の種類識別
    @State var imagecount = 0
    
    //永続化？秒数
    @AppStorage("timer_value") var timerValue = 10
    
    var body: some View {
        VStack{
            //スペース追加
            Spacer()
            
            //ジャンケン数字がゼロなら
            if ansorNumber == 0{
                
                Text(textbox)
                    .padding(.bottom)

                
            } else if ansorNumber == 1{
                
                
                
                
                //1ならグー
                //画像指定
                Image("gu").resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(Color.red)

                
                //ジャンケンの種類を指定
                Text("グー")
                    .padding(.bottom)
            } else if ansorNumber == 2{
                //2ならグー
                //画像指定
                Image("choki").resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(Color.yellow)

                //ジャンケンの種類を指定
                Text("チョキ").padding(.bottom)
            } else {
                //3ならグー
                //画像指定
                Image("pa").resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(Color.green)
                //ジャンケンの種類を指定
                Text("パー").padding(.bottom)
            }
            ZStack{
                
            }
            
            
            //ジャンケン実行？ボタン
            Button(action:{//押したときの反応
                
                //起動時の処理?
                startTimer()
//                  //処理したいコードを記述
//                    print("タップされた\(ansorNumber)")
//                    repeat{
//                        ansorNumber = Int.random(in: 1..<4)   // 1から3の範囲で整数（Int型）乱数を生成
//
//                    }while ansorNumber == bakusin
//
//                    //5%の答え
//                    rojita = Int.random(in: 1..<101)
//                    if rojita <= 5{
//                        print("ryaian")
//                        //ここで音声を鳴らすfuncを実行
//                        soundPlayer.lakkyPlay()
//                    }
//                    bakusin = ansorNumber
                
                
                
//                print("タップされた\(ansorNumber)")
//                repeat{
//                    ansorNumber = Int.random(in: 1..<4)   // 1から3の範囲で整数（Int型）乱数を生成
//
//                }while ansorNumber == bakusin
//
//                //5%の答え
//                rojita = Int.random(in: 1..<101)
//                if rojita <= 5{
//                    print("ryaian")
//                    //ここで音声を鳴らすfuncを実行
//                    soundPlayer.lakkyPlay()
//                }
//                bakusin = ansorNumber
                
            })
            {//ボタンの見た目？
                Text("ジャンケンをする")
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .font(.title)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    
            }
        }
       
        
    }
    func countDown() {
        
        //countに１秒足す
        count += 1
        
        //ジャンケンなのにすぐに手が出るのはおかしいのでウエイトを追加
        
        if (count == 1){
            
            textbox = "ジャン"
            

            
            
        } else if (count == 2){
            textbox = "ケン"
        }else {
            
            count = 0
              print("タップされた\(ansorNumber)")
              repeat{
                  ansorNumber = Int.random(in: 1..<4)   // 1から3の範囲で整数（Int型）乱数を生成
                  
              }while ansorNumber == bakusin
              
              //5%の確率でいい音を出す。
              rojita = Int.random(in: 1..<101)
              if rojita <= 5{
                  print("ryaian")
                  //ここで音声を鳴らすfuncを実行
                  soundPlayer.lakkyPlay()
              }
              bakusin = ansorNumber
        }
        
    }
    //カウントダウン開始の関数
    //
    func startTimer(){
        
        timerHandler = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { _ in
            //一秒毎にcountDownを呼び出す
            countDown()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
