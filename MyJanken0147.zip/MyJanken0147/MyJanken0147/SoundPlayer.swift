//
//  SoundPlayer.swift
//  MyJanken0147
//
//  Created by cmStudent on 2021/05/19.
//

import UIKit
import AVFoundation

class SoundPlayer: NSObject {
    //音源を読み込む
    let lakkyMusic = NSDataAsset(name: "lallySe45")!.data
    
    //音源を扱うための変数 (入れ物)
    var lakkyPlayer: AVAudioPlayer!
    
    //音を呼び出すときはfuncで呼ぶ？
    func lakkyPlay() {
        //音源を扱うにはdo catchが必須
        do{
            //ここで音源を入れ物に入れる
            lakkyPlayer = try AVAudioPlayer(data: lakkyMusic)
            
            //音源を再生
            lakkyPlayer.play()
        } catch {
            print("音源の設定エラー")
        }
        
    } //

}
