//
//  MyJanken0147App.swift
//  MyJanken0147
//
//  Created by cmStudent on 2021/05/13.
//

import SwiftUI

@main
struct MyJanken0147App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
