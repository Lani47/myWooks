//
//  ViewController.swift
//  BMICalculator
//
//  Created by npc on 2020/11/23.
//  Copyright © 2020 npc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tallTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    
    @IBOutlet weak var BMIText: UILabel!
    @IBOutlet weak var weightText: UILabel!
    
    
    
    let members = [
    ("99cm0101", (tall: 175.0, weight: 82.0)),
    ("99cm0102", (tall: 163.2, weight: 48.1)),
    ("99cm0103", (tall: 182.1, weight: 73.4)),
    ("99cm0104", (tall: 170.5, weight: 58.0)),
    ("99cm0105", (tall: 166.2, weight: 62.1)),
    ("99cm0106", (tall: 188.0, weight: 56.1)),
    ]
    // 文字列保存用の変数
        var textTall = ""
        var textweight = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        let result = calculatingBMI(tall: 170.0, weight: 52.0)
//        print(result.0)
//        print(result.1)
        for masu in members {
            let result = calculatingBMI(tall: masu.1.tall, weight: masu.1.weight)
            let roundDownResult = BMIroundDown(tall: result.0, ideal: result.1)
            print("BMIは\(roundDownResult.0)で、理想体重は\(roundDownResult.1)です。")
        }
        //キーボードを数字だけにする
        tallTextField.keyboardType = UIKeyboardType.numberPad
        weightTextField.keyboardType = UIKeyboardType.numberPad
    }
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }

        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            BMIText.text = BMIText.text
            self.view.endEditing(true)
        }
    
    
    /// 戻り値は(BMI, 理想体重)
    /// - Parameters:
    ///   - tall: 身長
    ///   - weight: 体重
    /// - Returns: BMIと理想体重
    func calculatingBMI(tall: Double, weight: Double) -> (Double, Double) {
        // 理想値
        let ideal = 22.0
        
        // 引数tallの値はcmである
        // 身長(m) × 身長(m)にするため、最後に100 * 100の値で割る
        let t2 = tall * tall / 10000.0
        
        let index = weight / t2
        return (index, ideal * t2)
    }
    //小数点を切り捨てるためのメゾット
    func BMIroundDown(tall: Double, ideal: Double) -> (Double, Double) {
        let  roundDownBMI = round(tall * 10)/10
        let roundDownIdeal = round(ideal * 10)/10
        return (roundDownBMI, roundDownIdeal)
    }
    @IBAction func AnsorButton(_ sender: Any) {
        // TextFieldから文字を取得
        textTall = tallTextField.text!
        textweight = weightTextField.text!
        //取得したテキストをDoubleに変換
        let nStr1:Double = Double(textTall)!
        let nStr2:Double = Double(textweight)!
        //BMIなどに変換して小数点を切る
        let result = calculatingBMI(tall: nStr1, weight: nStr2)
        let roundDownResult = BMIroundDown(tall: result.0, ideal: result.1)
        //処理した結果を表示
        BMIText.text = "BMIは:" + String(roundDownResult.0)
        weightText.text = "理想体重は:" + String(roundDownResult.1)
        
    }
    
}

